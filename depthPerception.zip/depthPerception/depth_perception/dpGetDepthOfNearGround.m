[depth_map] = dpGetDepthOfNearGround(depth_map, listOfBi, data, imsegs, coords, Dmin, Dmax)
