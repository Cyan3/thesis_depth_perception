function [top, bottom, left, right] = dmGetNeiborsPixels(pixel,size_i,size_j)
% Input:
% pixel - pixel care a este i*j
% size_i - marimea imaginii rows
% size_j - marimea imaginii collumns

[i ,j ] = dmGetTwoNumberIndex(pixel,size_j);


%top j - 1
if (j - 1 >= 1)
    top = dmGetOneNumberIndex(i, j - 1, size_j);
else 
    top = 0;
end

%bottom j + 1
if (j + 1 <= size_j)
    bottom = dmGetOneNumberIndex(i, j + 1, size_j);
else 
    bottom = 0;
end

%left i - 1
if (i - 1 >= 1)
    left = dmGetOneNumberIndex(i - 1, j, size_j);
else 
    left = 0;
end

%right i + 1
if (i + 1 <= size_i)
    right = dmGetOneNumberIndex(i + 1, j, size_j);
else 
    right = 0;
end

