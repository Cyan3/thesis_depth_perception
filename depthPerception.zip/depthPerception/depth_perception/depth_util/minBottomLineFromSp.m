function [ret] = minBottomLineFromSp(sp_index, data, imsegs)

max 