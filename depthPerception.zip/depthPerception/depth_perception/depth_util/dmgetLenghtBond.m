function [lenght] = dmgetLenghtBond(neiborPixelList, parentPixelList, size_i, size_j) 
%  neiborPixelList = lista cu indexul pixelor din superpixelul alaturi
%  parentPixelList = lista cu indexul pixelor din superpixelul parinte
lenght = 0;

for i = 1:size(parentPixelList)
    if dmIsNeiborWith(parentPixelList(i), neiborPixelList, size_i, size_j)
        lenght = lenght + 1;
    end
end