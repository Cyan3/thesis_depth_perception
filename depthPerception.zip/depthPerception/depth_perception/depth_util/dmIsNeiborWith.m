function [isNeibor] = dmIsNeiborWith(parent_p, child_bond_p, size_i, size_j)

[top, bottom, left, right] = dmGetNeiborsPixels(parent_p,size_i,size_j);
if (top ~= 0)
    if(ismember(top,child_bond_p))
        isNeibor = 1;
        return
    end
end
if (bottom ~= 0)
    if(ismember(bottom,child_bond_p))
        isNeibor = 1;
        return
    end
end
if (left ~= 0)
    if(ismember(left,child_bond_p))
        isNeibor = 1;
        return
    end
end
if (right ~= 0)
    if(ismember(right,child_bond_p))
        isNeibor = 1;
        return
    end
end
isNeibor = 0;