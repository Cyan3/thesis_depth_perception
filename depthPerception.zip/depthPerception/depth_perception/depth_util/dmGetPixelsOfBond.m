function [list] = dmGetPixelsOfBond(parent_pixels_bondary, child_pixel_bondary, ...
    size_i, size_j)

list = []
for i = 1:size(parent_pixels_bondary)
    if (dmIsNeiborWith(parent_pixels_bondary(i), child_pixel_bondary, size_i, size_j))
        list = [ list parent_pixels_bondary ];
    end
end