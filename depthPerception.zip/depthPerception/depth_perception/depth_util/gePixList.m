function gePixList(list_sp, index_sp)

