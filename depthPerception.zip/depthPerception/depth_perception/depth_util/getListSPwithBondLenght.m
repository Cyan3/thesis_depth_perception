function [list] = getListSPwithBondLenght(child_sp_index_list, ...
    child_sp_pixel_list, parent_sp_index, parent_sp_pixel, size_i, size_j)


for i = 1:size()
function [isNeibor] = dmIsNeiborWith(parent_p, child_bond_p, size_i, size_j)