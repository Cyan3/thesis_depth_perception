function [index] = dmGetOneNumberIndex(i, j, size_j)
index = j * size_j + i;
