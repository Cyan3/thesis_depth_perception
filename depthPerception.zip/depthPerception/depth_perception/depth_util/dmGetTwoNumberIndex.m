function [i, j] = dmGetTwoNumberIndex(index, nrCol)

if (rem(index,nrCol) == 0)
    i = fix(index/nrCol);
    j = nrCol;
else
    i = fix(index/nrCol) + 1;
    j = rem(index,nrCol) ;
end

