%radu = squeeze(mat);


%figure
%imshow(mat2gray(radu,[0 ,30]));
%imshow(mat2gray(a_data.imdata.gradim,[ 0 20 ]));

%find(data.adjlist == 100);
%a = a_data.imdata.pixlist;
%a = a.'
%a{1}(end)
%a = a_data.imdata.bndnpix;
%[c, b] = bounds(a)
%196
%find(a == 4021);
%all_neibors =  a_data.adjlist( find(a_data.adjlist(:,1) == 196), :);

%bond_pixel_parent = a_data.imdata.bndpixlist(196)

%bond_pixel_childs = a_data.imdata.bndpixlist(all_neibors(:,2));



%ismember(bond_pixel_parent{1},bond_pixel_childs{1,3})
a = [1 2 3; 4 5 6]


i = 2
j = 3
a(i,j)
% 1 3 4
% a_data.adjlist(:,1)
% 
% find(a_data.adjlist == 2)
% 
% 
% nr = 1 % nr sp parinte
% res = [] % indexes of neibors sp sp 
% res = a_data.adjlist(find(a_data.adjlist(:,1) == 29),2)


