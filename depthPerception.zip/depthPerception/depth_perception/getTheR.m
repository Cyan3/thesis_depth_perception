function R = getTheR(conf_map, imsegs)

R = [];



