function [depth] = getDepthForPixel(coords, index, min_d, max_d, size_i)

coords = coords * -1 + size_i/2;

depth = 0;
if (coords(end) > index) 
    depth = max_d;
    return 
end
asdf = size(coords,2)-1;
for i = 1:asdf
    asdfadf = coords(i);
    asdfadf1 = coords(i + 1);
    if and((asdfadf >= index),(asdfadf1 <= index ))
        depth = getDepthFromInterval(i,coords(i), coords(i + 1),index) + min_d;
        return
    end
end


