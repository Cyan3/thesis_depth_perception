function [depth] = getDepthFromInterval(unit, coords_i, coords_iPulsOne, index)

a = coords_i - coords_iPulsOne;
b = coords_i - index;

depth = b / a;

depth = unit + (depth);
