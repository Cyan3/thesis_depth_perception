function [depth_map] = setGroundDepthOnSp(depth_map, sp_num, imsegs, coords, Dmax, Dmin, size_i)

coords = coords * -1 + size(depth_map,1)/2;


for i = 1:imsegs.imsize(1)    
    for j = 1:imsegs.imsize(2)
        if imsegs.segimage(i,j) == sp_num
            depth_map(i,j) = getDepthForPixel(coords, i, Dmin, Dmax, size_i);
        end
    end
end    