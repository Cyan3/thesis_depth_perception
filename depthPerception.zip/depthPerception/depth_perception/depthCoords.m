function [coords, minDepth, maxDepth] = depthCoords(d, P, ROW, h, F, H)
%  [coords] = depth_coords(h, F, H, d, P)
% 
% Input:
%   h: the feature parameters of device
%   F: the feature parameters of device
%   H: the state parameters of device H
%   d: the unit depth
%   P: the point set, for now is the number of p
% . ROW: ﻿is the total rows of the processed image
% Output:
%   coords: ﻿The coordinate set
%step 1

if ~exist('h', 'var') || ~exist('F', 'var') || ~exist('H', 'var')
    D = 6;
else
    D = ( 2 * F * H )/ h;
end

%step 2
C = [];
y = - (ROW / 2);
C = [C, y];
for i = 0:P
    y = ((D + i * d) / (D + (i + 1)) * d) * y;
    C = [C, y];
end
coords = C;
minDepth = D;
maxDepth = P * d;







