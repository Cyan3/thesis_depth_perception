function [depth_map] = setSkyDepthOnSp(depth_map, sp_num, imsegs, Dmax)

for i = 1:imsegs.imsize(1)    
    for j = 1:imsegs.imsize(2)
        if imsegs.segimage(i,j) == sp_num
            depth_map(i,j) = Dmax; 
        end
    end
end    