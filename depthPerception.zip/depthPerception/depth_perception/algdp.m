function [depth_map] = algdp(pg, data, imsegs, coords, Dmin, Dmax)

[pv, ph] = splitpg(pg);

label_ph = ['ground' 'vertical' 'sky']
label_ph = ['left' 'center' 'right' 'porus' 'solid']

% Step 1
depth_map = zeros(imsegs.imsize);
RF = [];

R = [];
for i = 1:imsegs.nseg
    R = [R i];
end    

% Step 2
[vconf, vlab] = max(pv, [], 2);
[hconf, hlab] = max(ph, [], 2);

for i = 1:size(vlab,1)
    if vlab(i) == 3
        depth_map = setSkyDepthOnSp(depth_map, i, imsegs,Dmax);
        R = R(find(R~=i));
        RF = [RF i];
    end
end

% Step 3

for i = 1:size(vlab,1)
    if vlab(i) == 1
        depth_map = setGroundDepthOnSp(depth_map, i, imsegs, coords, Dmax, Dmin);
        R = R(find(R~=i));
        RF = [RF i];
    end
end

% Step 4
% sp care au labelul grownd
ground_plane_sp = []
for i = 1:size(vlab,1)
    if vlab(i) == 1
        ground_plane_sp = [ground_plane_sp i];
    end
end

sp_that_touch_ground = [];
sp_that_touch_ground_and_their_neibors = [];
y = size(R);
for i = 1:y(2)
    % neiboring points
    b1 = find(R(i) == data.adjlist(:,1));
    b = data.adjlist(b1,2);
    %is nebor 
    a = ismember(b, ground_plane_sp);
    if ismember(1,a)
        c = [a,b];
        % neibors with grownd labale from R(i)
        c = c(all(c,2),2);
        sp_that_touch_ground = [sp_that_touch_ground R(i)];
        tmp.sp_index = R(i);
        tmp.neibors_that_are_grownd = c;
        sp_that_touch_ground_and_their_neibors = [sp_that_touch_ground_and_their_neibors tmp]
    end
end


sp_that_touch_ground = sp_that_touch_ground.'
sp_that_touch_ground_and_their_neibors;
%iau cite un index_a_sp 
iSize = size(sp_that_touch_ground_and_their_neibors);

for i = 1:iSize(2)
    tmp = sp_that_touch_ground_and_their_neibors(i);
    jSize = size(tmp.neibors_that_are_grownd);
    for j = 1:jSize(1)
        [list] = dmGetPixelsOfBond( ...
        data.imdata.bndpixlist{tmp.sp_index}, ...
        data.imdata.bndpixlist{tmp.neibors_that_are_grownd(j)}, ...
        imsegs.segimage(1),imsegs.segimage(2));
    end
end


