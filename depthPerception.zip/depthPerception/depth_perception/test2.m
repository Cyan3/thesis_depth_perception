%l = load('data/ijcvClassifier.mat');


%[a_pg, a_data, a_imsegs] = ijcvTestImage (imread('test_dir/images/city10.jpg') ...
%,[] ....
%,l);


%[a_vlab, a_hlab, a_vw, a_hw] = segmentation2labels2(a_imsegs, a_data.smaps)
%[a_cimages, a_cnames] = pg2confidenceImages(a_imsegs,a_pg);
%figure
%image(a_cimages{1});
[coords, Dmin, Dmax] = depthCoords(0, 0, 0, 1, 50, a_imsegs.imsize(1));
dm = algdp(a_pg, a_data, a_imsegs, coords, min, max);
%depth = getDepthForPixel(coords, 540, 6, 50);


%figure
%imshow(mat2gray(dm,[0 ,50]))
