listing = dir('input_img_dir/');
outputDir = 'output_img_dir/'
for i = 4:size(listing,1)
    if 2 == size(listing,1)
    else
    [depth_map] = depthPerception(strcat(listing(i).folder,'/',listing(i).name), ...
        'classifier/ijcvClassifier.mat', 1, 50);
    
   
    greyImage = mat2gray(depth_map,[6,50]);
    
    rgbImage = greyImage(:,:, [1,1,1]);
    
    imwrite(rgbImage, [ outputDir 'output' ...
        num2str(i - 3) '.jpg'], 'quality', 100);
    end
    
end
