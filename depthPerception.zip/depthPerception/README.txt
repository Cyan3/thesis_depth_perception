1. Cutest read me la geometric context

2. dpFromIDirToODir - procesarea imaginilor din folder-ul input_img_dir 
In output_img_dir