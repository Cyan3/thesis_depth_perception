function [depth_map] = depthPerception(im_path, classifier_path, d, P, h, F, H) 
% Input:
% im - imaginea de prelucrare
% classifier - clasificatorul pentru segmentare
% d - unitatea de adâncime
% P - marimea de seturi de puncte p de pe planul de pămînt (de obicei 50)
% Optional
%  h: the feature parameters of device
%  F: the feature parameters of device
%  H: the state parameters of device H
%
% Output:
% depth_map - harta de adâncime




[pg, data, imsegs] = ijcvTestImage ( imread(im_path), [], load(classifier_path));

if ~exist('h', 'var') || ~exist('F', 'var') || ~exist('H', 'var')
    [coords, Dmin, Dmax] = depthCoords(d, P, imsegs.imsize(1));
else
    [coords, Dmin, Dmax] = depthCoords(d, P, imsegs.imsize(1), h, F, H);
end

R = []

[pv, ph] = splitpg(pg);

[vconf, vlab] = max(pv, [], 2);
[hconf, hlab] = max(ph, [], 2);

for i = 1:imsegs.nseg(1)
    tmp.index_sp = i;
    tmp.pixel_list = data.imdata.pixlist{i};
    tmp.pixel_bond_list = data.imdata.bndpixlist{i};
    tmp1 =size(data.imdata.pixlist{i});
    tmp.nr_pixel = tmp1(1);
    tmp.nr_bond_pixel = data.imdata.bndnpix(1,i);
    tmp.v_label = vlab(i);
    tmp.h_label = hlab(i);
    tmp.v_conf = vconf(i);
    tmp.h_conf = hconf(i);
    tmp.plist = [];
    tmp.bplist = [];
    tmp.depth = 0;
    R = [R ; tmp];
end

im_segs_mat = imsegs.segimage;
for i = 1:imsegs.imsize(1)
    ['process segment' num2str(i)] 
    for j = 1:imsegs.imsize(2)
        Ri = R(im_segs_mat(i,j));
        a =[ R(im_segs_mat(i,j)).plist ; [ i j ] ];
        R(im_segs_mat(i,j)).plist = a;
        [p_top, p_bot, p_left, p_right] = ...
            whoIsNeibor(Ri.index_sp, ...
            imsegs.segimage, ...
            i,j, ...
            imsegs.imsize(1), ...
            imsegs.imsize(2));
        
        if(p_top > 0)
            R(im_segs_mat(i,j)).bplist = [ R(im_segs_mat(i,j)).bplist ; [p_top , i, j] ];
        end
        if(p_bot > 0)
            R(im_segs_mat(i,j)).bplist = [ R(im_segs_mat(i,j)).bplist ; [p_bot , i, j] ];
        end
        if(p_left > 0)
            R(im_segs_mat(i,j)).bplist = [ R(im_segs_mat(i,j)).bplist ; [p_left , i, j] ];
        end
        if(p_right > 0)
            R(im_segs_mat(i,j)).bplist = [ R(im_segs_mat(i,j)).bplist ; [p_right , i, j] ];
        end
    end
end

for i = 1:imsegs.nseg(1)
    R(i).bplist = unique(R(i).bplist,'rows');
end

[depth_map] = dp_Alg(imsegs, R, coords, Dmin, Dmax);