l = load('/Users/radumanole/licenta/practic/GeometricContext_git/data/ijcvClassifier.mat');


[a_pg, a_data, a_imsegs] = ijcvTestImage (imread('/Users/radumanole/licenta/practic/GeometricContext_git/test_dir/images/alley01.jpg') ...
,[] ....
,l);


R = []
[coords, Dmin, Dmax] = depthCoords(0, 0, 0, 1, 50, a_imsegs.imsize(1));
[pv, ph] = splitpg(a_pg);

[vconf, vlab] = max(pv, [], 2);
[hconf, hlab] = max(ph, [], 2);

for i = 1:a_imsegs.nseg(1)
    tmp.index_sp = i;
    tmp.pixel_list = a_data.imdata.pixlist{i};
    tmp.pixel_bond_list = a_data.imdata.bndpixlist{i};
    tmp1 =size(a_data.imdata.pixlist{i});
    tmp.nr_pixel = tmp1(1);
    tmp.nr_bond_pixel = a_data.imdata.bndnpix(1,i);
    tmp.v_label = vlab(i);
    tmp.h_label = hlab(i);
    tmp.v_conf = vconf(i);
    tmp.h_conf = hconf(i);
    tmp.plist = [];
    tmp.bplist = [];
    tmp.depth = 0;
    R = [R ; tmp];
end
im = a_imsegs.segimage;
for i = 1:a_imsegs.imsize(1)
    for j = 1:a_imsegs.imsize(2)
        Ri = R(im(i,j));
        a =[ R(im(i,j)).plist ; [ i j ] ];
        R(im(i,j)).plist = a;
        [p_top, p_bot, p_left, p_right] = ...
            whoIsNeibor(Ri.index_sp, ...
            a_imsegs.segimage, ...
            i,j, ...
            a_imsegs.imsize(1), ...
            a_imsegs.imsize(2));
        
        if(p_top > 0)
            R(im(i,j)).bplist = [ R(im(i,j)).bplist ; [p_top , i, j] ];
        end
        if(p_bot > 0)
            R(im(i,j)).bplist = [ R(im(i,j)).bplist ; [p_bot , i, j] ];
        end
        if(p_left > 0)
            R(im(i,j)).bplist = [ R(im(i,j)).bplist ; [p_left , i, j] ];
        end
        if(p_right > 0)
            R(im(i,j)).bplist = [ R(im(i,j)).bplist ; [p_right , i, j] ];
        end
    end
end

for i = 1:a_imsegs.nseg(1)
    R(i).bplist = unique(R(i).bplist,'rows');
end

dp_Alg(a_pg, a_data, a_imsegs,R,coords, 6, 50);