function [top, bot, left, right] = whoIsNeibor(sp_index, im, i, j, size_i,size_j)
% Input:
% 
% size_i - marimea imaginii rows
% size_j - marimea imaginii collumns


%left j - 1
if (j - 1 >= 1)
    if (im(i,j - 1) == sp_index)
        left = 0;
    else
        left = im(i,j - 1);
    end
else 
    left = -1;
end

%right j + 1
if (j + 1 <= size_j)
    if (im(i,j + 1) == sp_index)
        right = 0;
    else
        right = im(i,j + 1);
    end
else 
    right = -1;
end

%top i - 1
if (i - 1 >= 1)
    if(im(i - 1, j) == sp_index)
        top = 0;
    else
        top = im(i - 1, j);
    end
else 
    top = -1;
end

%bot i + 1
if (i + 1 <= size_i)
    if(im(i + 1, j) == sp_index)
        bot = 0;
    else
        bot = im(i + 1, j);
    end
else 
    bot = -1;
end

