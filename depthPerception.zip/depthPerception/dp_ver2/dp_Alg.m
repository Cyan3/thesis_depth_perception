function [depth_map] = dp_Alg(imsegs, R, coords, Dmin, Dmax)
%
% Input:
% pg = matrice cu labelurile superpixelor 
%      dc folosesc functia split() imi da vlable hlabel unu cu 3 coloane
% .    care repvrezinta 1 = 'grownd' 2 = 'vertical' 3 = 'sky'
% data = data aranjata pentru din imsegs si pg impreuna
% imsegs = datele despre segmentarea imaginii
% R = datele de segmentare si label facute de @radu
% coords = coordonatele spatiului 3D
% Dmin Dmax = min si max adincimii
% Output:
% depth_map = 2d matrice cu adincimea in unitati ce is specificate in
% coordonate de obicei o unitate e 1 m , ar trebui sa fac sa fie parametru
% pentru coords

% marimea pixelor imaginii
nrRow = imsegs.imsize(1);
nrCol = imsegs.imsize(2);

% Step 1
% depth map with zeros everywhere
% and RF empty 
depth_map = zeros(imsegs.imsize);
RF = [];

% Step 2
% salvarea datelor R pentru mai usor sa accesez info din superp din toti R,
% pentru ca eu scot R elemente din R si le pun in RF
all_r = R;
% adincimea medie a col 1, in metri
all_r_d = zeros(size(all_r,1),1);

%adincimea in R
sR = size(R);
sR = sR(1);

flag = 1;
index = 1;
% merg pe toti superpixelii din R la rind
while flag == 1
    
    %is sp este 'sky'
    if R(index).v_label == 3
        % numarul de pixeli in superpixeli
        szd = size(R(index).plist,1);
        
        for psr = 1:szd
            % pun maximum pentru sp cu labelul sky
            ij_pixel = R(index).plist(psr,:); 
            depth_map(ij_pixel(1) ,ij_pixel(2)) = Dmax * 2;
        end
        % tin minte adincimea si in R si in all_r_d si sterg din R si il
        % pun in RF
        R(index).depth = Dmax * 2;
        all_r_d(R(index).index_sp)= R(index).depth;
        RF = [RF R(index)];
        R(index) = [];
        sR = sR - 1;
    else
        index = index + 1;
    end
    
    if (index > sR) flag = 0; end
end





R_tmp = R;
sR = size(R);
sR = sR(1);

flag = 1;
index = 1;
% Step 3 ground
while flag == 1
    %is grawnd
    if R(index).v_label == 1
        szd = size(R(index).plist,1);
        mean_depth = 0;
        for psr = 1:szd
            ij_pixel = R(index).plist(psr,:); 
            dep_s = getDepthForPixel(coords, ij_pixel(1), Dmin, Dmax,nrRow); 
            depth_map(ij_pixel(1) ,ij_pixel(2)) = dep_s;
                 
            mean_depth = mean_depth + dep_s;
        end
        R(index).depth = mean_depth/szd;
        all_r_d(R(index).index_sp) = R(index).depth;
        RF = [RF R(index)];
        R(index) = [];
        sR = sR - 1;
    else
        index = index + 1;
    end
    
    if (index > sR) flag = 0; end
end


% Step 4
R_tmp = R;
sR = size(R);
sR = sR(1);

flag = 1;
index = 1;
touchGsp = [];
while flag == 1
    bplist_mat = R(index).bplist;
    neibors = unique(bplist_mat(:,1));
    %get all the neibors of the i sp
    for i = 1:size(neibors)
        if all_r(neibors(i)).v_label == 1
            neibors(i,2) = 1;
        else
            neibors(i,2) = 0;
        end
    end
    % here are they
    neibors = neibors(all(neibors,2),:);
    
    % if we have neibors grownd, lets paint them and put them in a mat
    % to remove later
    dept_gr = 0;
    if ~isempty(neibors)
         bla = ismember(bplist_mat(:,1),neibors(:,1));
         bplist_mat = [bplist_mat  bla];
         blabla = all(bplist_mat,2);
         out = bplist_mat(blabla,:);
         minimun_i_p = max(out(:,2),[],1);
         dept_gr = getDepthForPixel(coords, minimun_i_p, Dmin, Dmax,nrRow);
         
         for psr = 1:size(R(index).plist,1)
            ij_pixel = R(index).plist(psr,:); 
            depth_map(ij_pixel(1) ,ij_pixel(2)) = dept_gr;
         end
         R(index).depth = dept_gr;
         all_r_d(R(index).index_sp) = R(index).depth;
         RF = [RF R(index)];
        R(index) = [];
        sR = sR - 1;
    end
    
    index = index + 1;
    
    if (index > sR) flag = 0; end
end

% step 6 - 7

for i = 1:size(RF,1)
    RF(i).maxbi = 0;
end


while ~isempty(R)
R_tmp = R;
sR = size(R);
sR = sR(1);

flag = 1;
index = sR;



for k = 1:size(R,1)
    R(k).maxbi = max(R(k).plist(:,1));
end
R = SortArrayofStruct( R, 'maxbi' );


while flag == 1
    bplist_mat = R(index).bplist;
    neibors = unique(bplist_mat(:,1));
    sk = size(bplist_mat(:,1),1);
    sl = size(neibors,1);
    neibors = [neibors zeros(sl,1)];
    
    for k = 1:sk
        for l = 1:sl
            if bplist_mat(k,1) == neibors(l,1)
                neibors(l,2) = neibors(l,2) + 1;
            end 
        end
    end
    
    depths  = [];
    for k = 1:sl
        l = neibors(k,1);
        blabla =  all_r_d(l,1);
        depths = [ depths ; blabla];
    end

    depths = [ double(neibors) depths ];
    
    indices = find(depths(:,3)==0);
    depths(indices,:) = [];
    
    if ~isempty(depths)
        rations = depths(:,2);
        rations = rations ./ sum(depths(:,2));
        dep = 0;
        for i = 1:size(depths,1)
            dep = dep + depths(i,3) * rations(i);
        end
        
        for psr = 1:size(R(index).plist,1)
            ij_pixel = R(index).plist(psr,:); 
            depth_map(ij_pixel(1) ,ij_pixel(2)) = dep;
         end
        
        R(index).depth = dep;
        all_r_d(R(index).index_sp) = R(index).depth;
        
        RF = [RF R(index)];
        R(index) = [];
        index = index - 2;

    else
        index = index - 1;

    end
    
    if (index < 1) flag = 0; end
end
end


