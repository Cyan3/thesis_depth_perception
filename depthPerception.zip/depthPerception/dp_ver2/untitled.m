im_path = '/Users/radumanole/licenta/practic/depthPerception/input_img_dir/alley01.jpg';
cl_path = '/Users/radumanole/licenta/practic/depthPerception/classifier/ijcvClassifier.mat';
[depth_map ] = depthPerception(im_path, cl_path, 1, 50); 

