% trainCRFScript

